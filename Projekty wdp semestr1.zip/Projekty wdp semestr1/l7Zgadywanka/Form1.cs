﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace l7Zgadywanka
{
    public partial class Form1 : Form
    {
        Random losowa = new Random();
        int liczbaDoOdgadniecia;
        int liczbaProb;


        public Form1()
        {
            InitializeComponent();
            liczbaDoOdgadniecia = losowa.Next(0,11);
            liczbaProb = 7;
            tbProby.Text = liczbaProb.ToString();
        }

        private void btnSprawdz_Click(object sender, EventArgs e)
        {
            int podanaLiczba = int.Parse(tbLiczba.Text);
            /*
            if ()
            {
                //liczbaProb--;
               // liczbaProb = liczbaProb - 1;
                liczbaProb -= 1;
                MessageBox.Show("Podaj mniejszą liczbę");
            }

            else if ()
            {
                MessageBox.Show("Podaj większą liczbę");
            }
            else
            {

            }
            */

        }
    }
}
