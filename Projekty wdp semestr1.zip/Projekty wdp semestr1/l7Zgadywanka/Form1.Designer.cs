﻿namespace l7Zgadywanka
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnSprawdz = new System.Windows.Forms.Button();
            this.tbLiczba = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tbProby = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btnSprawdz
            // 
            this.btnSprawdz.Location = new System.Drawing.Point(53, 110);
            this.btnSprawdz.Name = "btnSprawdz";
            this.btnSprawdz.Size = new System.Drawing.Size(109, 57);
            this.btnSprawdz.TabIndex = 0;
            this.btnSprawdz.Text = "Sprawdź";
            this.btnSprawdz.UseVisualStyleBackColor = true;
            this.btnSprawdz.Click += new System.EventHandler(this.btnSprawdz_Click);
            // 
            // tbLiczba
            // 
            this.tbLiczba.Location = new System.Drawing.Point(190, 110);
            this.tbLiczba.Name = "tbLiczba";
            this.tbLiczba.Size = new System.Drawing.Size(64, 20);
            this.tbLiczba.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(53, 224);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(62, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Liczba prób";
            // 
            // tbProby
            // 
            this.tbProby.Location = new System.Drawing.Point(130, 221);
            this.tbProby.Name = "tbProby";
            this.tbProby.Size = new System.Drawing.Size(32, 20);
            this.tbProby.TabIndex = 3;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(285, 272);
            this.Controls.Add(this.tbProby);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tbLiczba);
            this.Controls.Add(this.btnSprawdz);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnSprawdz;
        private System.Windows.Forms.TextBox tbLiczba;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbProby;
    }
}

