﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZmienneAk3
{
    class Program
    {
        static void Main(string[] args)
        {
            // komentarz jednowierszowy

            /*
            Komentarz 
            wielowieroszwy
              
              
             */

            //ZMIENNE w C#

            //typ dla liczb całkowitych
            /*  int zmiennaInt= 45979879;
              long zmiennaLong = -678679657956795679;


              //typ dla ułamków
              float zmiennaFloat = 45.23547f;

              double zmiennaDouble = -54.23754;

              decimal zmiennaDecimal = 56.23456m;

              //typ na tekst

              string zmiennaString = "Język C#";

              //typ na pojedynczy znak
              char zmiennaChar = '#';

              //Typ logiczny
              bool zmiennaBool = true;   //false

              //Wyświetlanie danych na konsoli

              //1 sposób

              Console.WriteLine("Zmienna int ma wartość: " + zmiennaInt + " a zmienna char ma wartość: " + zmiennaChar);

              //2 sposób
              Console.WriteLine("Zmienna int ma wartość: {0} a zmienna char ma wartość: {1}",zmiennaInt,zmiennaChar);

              //3 sposób

              Console.WriteLine($"Zmienna int ma wartość: {zmiennaInt} a zmienna char ma wartość: {zmiennaChar}");
            */

            




            Console.ReadLine();
        }
    }
}
