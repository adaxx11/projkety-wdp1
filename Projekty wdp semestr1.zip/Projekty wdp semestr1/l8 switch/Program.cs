﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace l8_switch
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
            Console.WriteLine("Podaj numer dnia tygodnia (1-7)");
            // "7"--> 7
            int dzien = int.Parse(Console.ReadLine());

            if (dzien==1)
            {
                Console.WriteLine("Pierwszy dzień tygodnia to poniedziałek");
            }
            else if (dzien == 2)
            {
                Console.WriteLine("Pierwszy dzień tygodnia to wtorek");
            }

            */


            //SWITCH

            //Console.WriteLine("Podaj jaką ocenę dostałeś");
            //int ocena = int.Parse(Console.ReadLine());

            //switch (ocena)
            //{
            //    case 6:
            //        Console.WriteLine("Celujący");
            //        break;
            //    case 5:
            //        Console.WriteLine("Bardzo dobry");
            //        break;
            //    case 4:
            //        Console.WriteLine("Dobry");
            //        break;
            //    default:
            //        Console.WriteLine("Nieprawidłowa ocena");
            //        break;

            //}

            Console.WriteLine("Podaj nazwę miesiąca albo numer(1-12)");
            string podanyMiesiac = Console.ReadLine();

            switch (podanyMiesiac)
            {
                case "1":
                case "styczeń":
                    Console.WriteLine("January");
                    break;

                case "2":
                case "luty":
                    Console.WriteLine("February");
                    break;
            }
            

           

            Console.ReadLine();
        }
    }
}
