﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace l10Petle
{
    class Program
    {
        static void Main(string[] args)
        {

            //Pętla while
            
            //int i = 0;
            //while (i <= 10)
            //{
            //    Console.WriteLine(i);
            //    i++;
            //}

            /*
            Console.WriteLine("Podaj częśtotliwość dźwięku");
            //37Hz-20000Hz
            int czestotliwosc = int.Parse(Console.ReadLine());

            while (czestotliwosc<=20000)
            {
                Console.Beep(czestotliwosc, 500);
                Console.WriteLine($"aktualna częstlotliwość to{czestotliwosc }");

                //czestotliwosc += 500;
                czestotliwosc = czestotliwosc + 500;
            }
            */


            //pętla for
/*
            DateTime start = DateTime.Now;

            for (int i=0;i<=5000;i++)
            {
                Console.WriteLine(i);
            }
            DateTime koniec = DateTime.Now;

            Console.WriteLine($"Data rozpoczecia wypisywania{start} ");
            Console.WriteLine($"Data rozpoczecia wypisywania{koniec} ");
            Console.ReadLine();
*/


            //za pomocą pętli while oraz for wypisz wartości od 5000 do 0

           /* int i = 5000;
            while (i >= 0){
                Console.WriteLine(i);
                i--;
            }
           */
            for (int i = 5000; i >= 0; i--)
            {
                Console.WriteLine(i);
            }


            Console.ReadLine();
        }
    }
}
