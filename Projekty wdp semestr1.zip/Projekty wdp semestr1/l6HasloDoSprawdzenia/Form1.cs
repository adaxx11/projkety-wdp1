﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace l6HasloDoSprawdzenia
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSprawdz_Click(object sender, EventArgs e)
        {
            string haslo = tbHaslo.Text;

            if (string.IsNullOrWhiteSpace(haslo))
            {
                MessageBox.Show("Hasło nie może być puste");
            }

            else if (haslo.Length < 8)
            {
                MessageBox.Show("Hasło jest za krótkie");
            }
            else if (!(haslo.Contains("?") || haslo.Contains("@")))
            {
                MessageBox.Show("Hasło nie zawiera znakow specjalnych");

            }
            else
            {
                MessageBox.Show("Hasło jest ok");
            }



        }
    }
}
