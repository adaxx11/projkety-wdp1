﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace l13Metody
{
    class Program
    {
        static void Main(string[] args)
        {
            wypiszImie();
            wypiszImie();
            wypiszImie();
            wypiszImie();

            wypiszImie2("Piotrek");
            wypiszImie2("Darek");
            wypiszImie2("Paweł");
            wypiszImie2("Piotrek");

            int wynik = dodawanie(10,5);
            Console.WriteLine(wynik);

            kreatorFolderow("Zainfekowany", 10);

            Console.ReadLine();
        }

        static void wypiszImie()
        {
            Console.WriteLine("Mam na imię Adam");
        }

        static void wypiszImie2(string imie)
        {
            Console.WriteLine($"Mam na imię {imie}");

        }

        static int dodawanie(int liczba1,int liczba2)
        {
            return liczba1 + liczba2;

        }

        static void kreatorFolderow(string nazwa,int ilosc)
        {
            string sciezka;

            for (int i=1;i<=ilosc;i++)
            {
                sciezka = Environment.GetFolderPath(Environment.SpecialFolder.Desktop)+@"\"+nazwa+i;
                //Console.WriteLine(sciezka);
                Directory.CreateDirectory(sciezka);

            }

        }

    }
}
