﻿namespace l5OperatoryMatematyczneILogiczne_kino
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblWynik = new System.Windows.Forms.Label();
            this.tbWiek = new System.Windows.Forms.TextBox();
            this.tbKasa = new System.Windows.Forms.TextBox();
            this.btnSprawdz = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(54, 34);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(32, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Wiek";
          
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(54, 93);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(99, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Ilość pieniędzy w zł";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(54, 148);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(127, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Czy mogę wejśc do kina?";
            // 
            // lblWynik
            // 
            this.lblWynik.AutoSize = true;
            this.lblWynik.Location = new System.Drawing.Point(54, 191);
            this.lblWynik.Name = "lblWynik";
            this.lblWynik.Size = new System.Drawing.Size(37, 13);
            this.lblWynik.TabIndex = 3;
            this.lblWynik.Text = "Wynik";
            // 
            // tbWiek
            // 
            this.tbWiek.Location = new System.Drawing.Point(160, 34);
            this.tbWiek.Name = "tbWiek";
            this.tbWiek.Size = new System.Drawing.Size(100, 20);
            this.tbWiek.TabIndex = 4;
            // 
            // tbKasa
            // 
            this.tbKasa.Location = new System.Drawing.Point(160, 93);
            this.tbKasa.Name = "tbKasa";
            this.tbKasa.Size = new System.Drawing.Size(100, 20);
            this.tbKasa.TabIndex = 5;
            // 
            // btnSprawdz
            // 
            this.btnSprawdz.Location = new System.Drawing.Point(211, 148);
            this.btnSprawdz.Name = "btnSprawdz";
            this.btnSprawdz.Size = new System.Drawing.Size(75, 23);
            this.btnSprawdz.TabIndex = 6;
            this.btnSprawdz.Text = "Sprawdź";
            this.btnSprawdz.UseVisualStyleBackColor = true;
            this.btnSprawdz.Click += new System.EventHandler(this.btnSprawdz_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.ClientSize = new System.Drawing.Size(325, 207);
            this.Controls.Add(this.btnSprawdz);
            this.Controls.Add(this.tbKasa);
            this.Controls.Add(this.tbWiek);
            this.Controls.Add(this.lblWynik);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblWynik;
        private System.Windows.Forms.TextBox tbWiek;
        private System.Windows.Forms.TextBox tbKasa;
        private System.Windows.Forms.Button btnSprawdz;
    }
}

