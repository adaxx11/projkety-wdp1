﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace l5OperatoryMatematyczneILogiczne_kino
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSprawdz_Click(object sender, EventArgs e)
        {
            const int wymaganyWiek = 16;
            const decimal cenaBiletu = 35.50m;

            int wiek = int.Parse(tbWiek.Text);
            decimal kasa = decimal.Parse(tbKasa.Text);

            //operatory matematyczne
            // > , <  ,>= , <=, == ,!= 

            //operatory logiczne
            // logiczne i &&
            // logicze lub ||
            //negacja ! !true=false

            //bool wynik = wiek >= wymaganyWiek && kasa >= cenaBiletu;

            //lblWynik.Text = wynik.ToString();

            if (wiek >= wymaganyWiek && kasa >= cenaBiletu)
            {
                lblWynik.Text = "Tak, możesz wejść do Kina";

            }
            else
            {
                lblWynik.Text = "Nie możesz wejść do kina";
            }


        }

        
    }
}
