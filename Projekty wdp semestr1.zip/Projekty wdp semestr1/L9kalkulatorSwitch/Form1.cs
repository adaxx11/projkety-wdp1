﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace L9kalkulatorSwitch
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnOblicz_Click(object sender, EventArgs e)
        {
            float pierwsza = float.Parse(tbPierwsza.Text);
            float druga = float.Parse(tbDruga.Text);
            float wynik;
            string dzialanie = cbDzialanie.Text;
            label1.Text = dzialanie;
            switch (dzialanie)
            {   
                case "Dodawanie":
                    wynik = pierwsza + druga;
                    tbWynik.Text = wynik.ToString();
                    break;

                case "Odejmowanie":
                    wynik = pierwsza - druga;
                    tbWynik.Text = wynik.ToString();
                    break;
            }
        }
    }
}
