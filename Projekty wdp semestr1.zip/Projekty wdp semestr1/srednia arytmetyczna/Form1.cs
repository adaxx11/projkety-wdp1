﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace srednia_arytmetyczna
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnOblicz_Click(object sender, EventArgs e)
        {           // z takiej "5" taką 5
            int ocenaMatematyka = int.Parse(tbMatematyka.Text);
            int ocenaInformatyka = int.Parse(tbInformatyka.Text);
            int ocenaFizyka = int.Parse(tbFizyka.Text);
          
            int sumaOcen = ocenaFizyka + ocenaInformatyka + ocenaMatematyka;

            // dla int 5/2=2     rzutowanie
            float srednia = (float)sumaOcen / 3;
            tbWynik.Text = srednia.ToString();

        }
    }
}
