﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tic_tac_toe
{
    public partial class Form1 : Form
    {
        // true to gra X a jeśli false to gra O

        bool czyjRuch = true;
        int licznik = 0;
       
        public Form1()
        {
            InitializeComponent();
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
            WstawZnak(sender);

        }
        
        private void button2_Click(object sender, EventArgs e)
        {
            WstawZnak(sender);

        }

        private void button3_Click(object sender, EventArgs e)
        {
            WstawZnak(sender);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            WstawZnak(sender);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            WstawZnak(sender);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            WstawZnak(sender);
        }

        private void button7_Click(object sender, EventArgs e)
        {
            WstawZnak(sender);
        }

        private void button8_Click(object sender, EventArgs e)
        {
            WstawZnak(sender);
        }

        private void button9_Click(object sender, EventArgs e)
        {
            WstawZnak(sender);
        }


        private  void WstawZnak(object przycisk)
        {
            
            Button wcisnietyPrzycisk = (Button)przycisk;

            if (czyjRuch)
            {
                wcisnietyPrzycisk.Text = "X";

            }

            else
            {
                wcisnietyPrzycisk.Text = "O";

            }

            wcisnietyPrzycisk.Enabled = false;

            bool wynik = false;
            
            if (wynik)
            {
                string tekstWygranej;

                if (czyjRuch)
                {
                    tekstWygranej = "Wygrał gracz X! Czy chcesz zagrać jeszcze raz?";

                }
                else
                {
                    tekstWygranej = "Wygrał gracz O! Czy chcesz zagrać jeszcze raz?";
                }

                DialogResult odp = MessageBox.Show(tekstWygranej, "WYGRANA", MessageBoxButtons.YesNo,MessageBoxIcon.Information);

                if (odp == DialogResult.No)
                {
                    Application.Exit();

                }
                else
                {
                  // nowaGra();

                }
            }

            czyjRuch = !czyjRuch;

            if (czyjRuch)
            {
                lblRuch.Text = "X";
            }
            else
            {
                lblRuch.Text = "0";
            }
        }








    }
}
