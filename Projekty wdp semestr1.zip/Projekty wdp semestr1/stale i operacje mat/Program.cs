﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace stałe_i_operacje_matematyczne
{
    class Program
    {
        static void Main(string[] args)
        {

          // string imie = "Adam";
          int liczba = 12;

          bool zmienna = true;
         char znak = '#';

         float ulamek  = 1.4f;

         double ulamek2 = 1.567;

         decimal ulamek3 = 1.543m;

            //Wyświetlanie danych na konsoli

            /*
            //1 sposób

            Console.WriteLine("Zmienna float ma wartość: " + zmiennaFloat + " a zmienna decimal ma wartość: " + zmiennaDecimal);

            //2 sposób

            Console.WriteLine("Zmienna float ma wartość: {0} a zmienna decimal ma wartość: {1}", zmiennaFloat, zmiennaDecimal);

            //3 sposób

            Console.WriteLine($"Zmienna float ma wartość: {zmiennaFloat} a zmienna decimal ma wartość: {zmiennaDecimal}"
*/

            //zadanie

            //stwórz zmienne i przypisz do nich odpowiednie wartości. Następnie wyświetl za pomocą wybranego sposobu.
            //imie, nazwisko, wiek ulubiona potrawa , tytul ulubionej piosenki , czy dojeżdżacie do szkoły autobusem(bool), ilość gotówki(ułamek)

            //np  Mam na imię Jan Kowalski, mam 14 lat moją ulubioną potrawą jest kebab, moja ulubiona piosenka to Imagine dragons, czy dojeżdzam autobusem:true, mam przy sobie 15.50zł


            //stałe

            int liczba1 = 4;
            Console.WriteLine(liczba1);
            liczba1 = 10;
            Console.WriteLine(liczba1);

            const int liczba2 = 5;
            Console.WriteLine(liczba2);
            // liczba2 = 10; to jest błąd

            //operacje matematyczne
            // dodawanie +
            //odejmowanie -
            //mnożenie *
            //dzielenie /

            //tworzymy 3 stałe typu int:  d , e ,f         wzór 4 * d + 3 - e * 7 - f
            const int d = 5;
            const int e = 8;
            const int f = 7;
            int wynik = 4 *d + 3 - e * 7 - f;
            Console.WriteLine($"Wynik działania to {wynik}");
          


            //program liczący obwód koła

            const float PI = 3.14f;
            Console.WriteLine("Program obliczający obwód koła");
            Console.WriteLine("Podaj promień koła");
            // "55"+"5"="555"
            //    55+5=60
            float promien = float.Parse(Console.ReadLine());
            float obwod = 2 * PI * promien;
            Console.WriteLine($"Obwód koła wynosi: {obwod}");

            //napisz program przeliczający euro na złotówki
            //przejdź na stronę https://www.kantor.pl/kursy-walut i sprawdź aktualny kurs, jeśli chcemy sprzedzać euro patrzymy na kolumnę kupno(po ile kantor kupi od nas walutę)
            //daną wartość zapisz do stałej typu decimal
            //kwotę euro pobieramy od użytkownika za pomocą polecenia Console.ReadLine() pamiętaj o parsowaniu decimal.Parse()
            //wyswietlając dane wykorzystaj specyfikator formatowania "C", który odnosi się do waluty Currency-waluta np.
            //Console.WriteLine($"Otrzymasz {zlotowki:C}");

            //utwórz stała typu decimal do któej zapiszesz aktualny kurs
            const decimal kurs = 4.5998m;
            //wyświetl użytkownikowi pytanie np.Podaj jaką kwotę euro posiadasz
            Console.WriteLine("Podaj jaką kwotę euro posiadasz");
            //pobierz od użytkownika dane 
            decimal euro = decimal.Parse(Console.ReadLine());
            //wykonaj obliczenia i przypisz do zmiennej typu decimal
            decimal zlotowki = euro * kurs;
            //wyświetl odpowiedź
            Console.WriteLine($"Otrzymasz {zlotowki:C2}");

            Console.ReadLine();


        }
    }
}
