﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace l11Tablice
{
    class Program
    {
        static void Main(string[] args)
        {
            //TABLICE

            string[] tablicaImion = {"Adam","Marek","Michał","Janek","Darek","Paweł" };

            Console.WriteLine(tablicaImion[4]);

            for (int i=0;i<tablicaImion.Length;i++)
            {
                Console.WriteLine($"Indeks w tablicy {i} a element o tym indeksie to {tablicaImion[i]}");

            }


            int[] tabLiczby = { 433,50,3000, 7, 54, 34444, -43332, 654, 7869, 54, 22, 112 };

            int aktualnieNajwieksza = tabLiczby[0];
            int aktualnieNajmniejsza= tabLiczby[0];
            for (int j=0;j<tabLiczby.Length;j++) 
            {
                if (aktualnieNajwieksza<tabLiczby[j])
                {
                    aktualnieNajwieksza = tabLiczby[j];
                }

                if (aktualnieNajmniejsza>tabLiczby[j])
                {
                    aktualnieNajmniejsza = tabLiczby[j];

                }
            }

            Console.WriteLine(aktualnieNajwieksza);
            Console.WriteLine(aktualnieNajmniejsza);

            Console.ReadLine();
        }
    }
}
