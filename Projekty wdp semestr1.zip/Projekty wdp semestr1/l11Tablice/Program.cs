﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace l11Tablice
{
    class Program
    {
        static void Main(string[] args)
        {
            //TABLICE

            string[] tablicaImion = {"Adam","Marek","Michał","Janek","Darek","Paweł" };

            Console.WriteLine(tablicaImion[4]);

            for (int i=0;i<tablicaImion.Length;i++)
            {
                Console.WriteLine($"Indeks w tablicy {i} a element o tym indeksie to {tablicaImion[i]}");

            }


            int[] tabLiczby = { 433,50,3000, 7, 54, 34444, -43332, 654, 7869, 54, 22, 112 };

            int aktualnieNajwieksza = tabLiczby[0];
            int aktualnieNajmniejsza= tabLiczby[0];
            for (int j=0;j<tabLiczby.Length;j++) 
            {
                if (aktualnieNajwieksza<tabLiczby[j])
                {
                    aktualnieNajwieksza = tabLiczby[j];
                }

                if (aktualnieNajmniejsza>tabLiczby[j])
                {
                    aktualnieNajmniejsza = tabLiczby[j];

                }
            }

            Console.WriteLine(aktualnieNajwieksza);
            Console.WriteLine(aktualnieNajmniejsza);

            ////////////////KINO


            Console.WriteLine("Witamy w naszym kinie!");

            //stwórz tablicę typu string o nazwie filmy, dodaj do niej przynajmniej 3 wybrane przez siebie filmy.
            string[] filmy = {"Godzilla","Harry Potter","Batman","Titanic"};
            //Tablica infoRezerwacyjne z zadeklarowaną wielkością
            string[] infoRezerwacyjne = new string[6];
            //stwórz tablicę typu string  o nazwie dane dodaj do niej takie elementy jak Film, Imie, Nazwisko, E-mail, Telefon, Liczba biletów
            string[] dane = { "Film", "Imię", "Nazwisko", "E-mail", "Telefon", "Liczba biletów" };
            //stwórz zmienną cenaBiletu typu decimal i przypisz jakąś kwotę
            decimal cenaBiletu = 35.50m;

            Console.WriteLine("Wybierz film:");
            //za pomocą pętli for z tablicy filmy wyświetlamy wszystkie filmy dodatkowo wyświetlamy liczby porządkowe możemy skorzystać z licznika pętli i, ale pamiętaj że numeracja w tablicach jest od 0
            for (int i = 0; i < filmy.Length; i++)
            {
                Console.WriteLine($"{i+1}. {filmy[i]}");
            }
            //tworzymy zmienną typu int o nazwie wybor i przypisujemy do niej wybór użytkownika skorzystaj z Console.ReadLine() oraz parsowania
            int wybor = int.Parse(Console.ReadLine());
            //za pomocą switcha uzupełnij pierwszy element w tablicy infoRezerwacyjne w zależności od tego co wybrał użytkownik
            switch (wybor - 1)
            {
                case 0:
                    infoRezerwacyjne[0] = filmy[0];
                    break;
                case 1:
                    infoRezerwacyjne[0] = filmy[1];
                    break;
                case 2:
                    infoRezerwacyjne[0] = filmy[2];
                    break;

                case 3:
                    infoRezerwacyjne[0] = filmy[3];
                    break;

                default:
                    Console.WriteLine("Dokonano złego wyboru");
                    break;
            }





            Console.WriteLine("Podaj następujące dane");
            for (int i = 1; i < infoRezerwacyjne.Length; i++)
            {
                //pobieramy od użytkownika dane rezerwacji bazujemy na tablicy o nazwie dane
                Console.WriteLine($"Podaj {dane[i]}:");
                infoRezerwacyjne[i] = Console.ReadLine();
            }


            Console.WriteLine("Podsumowanie rezerwacji:");
            Console.WriteLine();

            for (int i = 0; i < infoRezerwacyjne.Length; i++)
            {
                //wyświetlamy podsumowanie rezerwacji
                Console.WriteLine($"{dane[i]}: {infoRezerwacyjne[i]}");
            }
            //tworzymy zmienna koszt typu decimal do której zapisujemy wynik mnożenia ceny biletu* ich ilość

            decimal koszt = cenaBiletu * decimal.Parse(infoRezerwacyjne[5]);
            //Wyświetlamy łączną cenę biletów
            Console.WriteLine($"Łączna cena biletów to {koszt} zł");
            Console.ReadKey();






            Console.ReadLine();
        }
    }
}
