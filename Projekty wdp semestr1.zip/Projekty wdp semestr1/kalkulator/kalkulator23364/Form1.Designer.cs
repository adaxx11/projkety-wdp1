﻿namespace kalkulator23364
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.label1 = new System.Windows.Forms.Label();
            this.nudLiczba1 = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            this.nudLiczba2 = new System.Windows.Forms.NumericUpDown();
            this.btnDodaj = new System.Windows.Forms.Button();
            this.btnPomnoz = new System.Windows.Forms.Button();
            this.btnOdejmij = new System.Windows.Forms.Button();
            this.btnPodziel = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.tbWynik = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.nudLiczba1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudLiczba2)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(53, 57);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(82, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Liczba pierwsza";
            // 
            // nudLiczba1
            // 
            this.nudLiczba1.Location = new System.Drawing.Point(162, 55);
            this.nudLiczba1.Maximum = new decimal(new int[] {
            999999999,
            0,
            0,
            0});
            this.nudLiczba1.Minimum = new decimal(new int[] {
            999999999,
            0,
            0,
            -2147483648});
            this.nudLiczba1.Name = "nudLiczba1";
            this.nudLiczba1.Size = new System.Drawing.Size(120, 20);
            this.nudLiczba1.TabIndex = 1;
            this.nudLiczba1.ThousandsSeparator = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(53, 98);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(68, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Liczba druga";
            // 
            // nudLiczba2
            // 
            this.nudLiczba2.Location = new System.Drawing.Point(162, 91);
            this.nudLiczba2.Maximum = new decimal(new int[] {
            999999999,
            0,
            0,
            0});
            this.nudLiczba2.Minimum = new decimal(new int[] {
            1410065407,
            2,
            0,
            -2147483648});
            this.nudLiczba2.Name = "nudLiczba2";
            this.nudLiczba2.Size = new System.Drawing.Size(120, 20);
            this.nudLiczba2.TabIndex = 3;
            this.nudLiczba2.ThousandsSeparator = true;
            // 
            // btnDodaj
            // 
            this.btnDodaj.Location = new System.Drawing.Point(56, 156);
            this.btnDodaj.Name = "btnDodaj";
            this.btnDodaj.Size = new System.Drawing.Size(75, 23);
            this.btnDodaj.TabIndex = 4;
            this.btnDodaj.Text = "Dodaj";
            this.btnDodaj.UseVisualStyleBackColor = true;
            this.btnDodaj.Click += new System.EventHandler(this.btnDodaj_Click);
            // 
            // btnPomnoz
            // 
            this.btnPomnoz.Location = new System.Drawing.Point(177, 156);
            this.btnPomnoz.Name = "btnPomnoz";
            this.btnPomnoz.Size = new System.Drawing.Size(75, 23);
            this.btnPomnoz.TabIndex = 5;
            this.btnPomnoz.Text = "Pomnóż";
            this.btnPomnoz.UseVisualStyleBackColor = true;
            this.btnPomnoz.Click += new System.EventHandler(this.btnPomnoz_Click);
            // 
            // btnOdejmij
            // 
            this.btnOdejmij.Location = new System.Drawing.Point(56, 206);
            this.btnOdejmij.Name = "btnOdejmij";
            this.btnOdejmij.Size = new System.Drawing.Size(75, 23);
            this.btnOdejmij.TabIndex = 6;
            this.btnOdejmij.Text = "Odejmij";
            this.btnOdejmij.UseVisualStyleBackColor = true;
            this.btnOdejmij.Click += new System.EventHandler(this.btnOdejmij_Click);
            // 
            // btnPodziel
            // 
            this.btnPodziel.Location = new System.Drawing.Point(177, 206);
            this.btnPodziel.Name = "btnPodziel";
            this.btnPodziel.Size = new System.Drawing.Size(75, 23);
            this.btnPodziel.TabIndex = 7;
            this.btnPodziel.Text = "Podziel";
            this.btnPodziel.UseVisualStyleBackColor = true;
            this.btnPodziel.Click += new System.EventHandler(this.btnPodziel_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(53, 254);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(37, 13);
            this.label3.TabIndex = 8;
            this.label3.Text = "Wynik";
            // 
            // tbWynik
            // 
            this.tbWynik.Location = new System.Drawing.Point(99, 254);
            this.tbWynik.Name = "tbWynik";
            this.tbWynik.Size = new System.Drawing.Size(198, 20);
            this.tbWynik.TabIndex = 9;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(342, 301);
            this.Controls.Add(this.tbWynik);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btnPodziel);
            this.Controls.Add(this.btnOdejmij);
            this.Controls.Add(this.btnPomnoz);
            this.Controls.Add(this.btnDodaj);
            this.Controls.Add(this.nudLiczba2);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.nudLiczba1);
            this.Controls.Add(this.label1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "Kalkulator";
            ((System.ComponentModel.ISupportInitialize)(this.nudLiczba1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudLiczba2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.NumericUpDown nudLiczba1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.NumericUpDown nudLiczba2;
        private System.Windows.Forms.Button btnDodaj;
        private System.Windows.Forms.Button btnPomnoz;
        private System.Windows.Forms.Button btnOdejmij;
        private System.Windows.Forms.Button btnPodziel;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tbWynik;
    }
}

